import streamlit as st

st.title("Test")
st.write("If you see this, Streamlit works!")
st.button("Click me")